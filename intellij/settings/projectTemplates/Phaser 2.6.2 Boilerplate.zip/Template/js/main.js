/**
 * Created by ${USER} on ${DATE}.
 */


var Template = Template || {};

var game = new Phaser.Game("100%", "100%", Phaser.CANVAS);

game.state.add("boot", new Template.Boot());
game.state.add("loading", new Template.Loading());
game.state.add("level", new Template.Level());

game.state.start("boot", true, false, "assets/json/test.json");