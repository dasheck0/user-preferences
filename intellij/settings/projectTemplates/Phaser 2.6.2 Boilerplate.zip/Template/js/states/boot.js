/**
 * Created by ${USER} on ${DATE}.
 */


var Template = Template || {};

Template.Boot = function() {
    "use strict";
    Phaser.State.call(this);
};

Template.Boot.prototype = Object.create(Phaser.State.prototype);
Template.Boot.prototype.constructor = Template.Boot;

Template.Boot.prototype.init = function(data) {
    "use strict";
    this.data = data;
};

Template.Boot.prototype.preload = function() {
    "use strict";
    this.load.text("data", this.data);
};

Template.Boot.prototype.create = function() {
    "use strict";
    var content = this.game.cache.getText("data");
    var payload = JSON.parse(content);

    this.game.state.start("loading", true, false, payload);
};